window.onload = function() {
    const videoPlayer = document.getElementById('videoPlayer');
    const fileInput = document.getElementById('fileInput');
    const playbackRateSelect = document.getElementById('playbackRate');
    const qualitySelect = document.getElementById('quality');
    const playlist = document.getElementById('playlistItems');
    const mostWatched = document.getElementById('mostWatchedItems');
    const logoInput = document.getElementById('logoInput');
    const logoPreview = document.getElementById('logoPreview');
    const appTitle = document.getElementById('appTitle');

    logoInput.addEventListener('change', function(event) {
        const file = event.target.files[0];
        const url = URL.createObjectURL(file);
        logoPreview.src = url;
    });

    logoPreview.addEventListener('click', function() {
        logoPreview.src = '';
    });

    videoPlayer.onplay = function() {
        console.log('تم تشغيل الفيديو.');
    };

    videoPlayer.onpause = function() {
        console.log('تم إيقاف تشغيل الفيديو.');
    };

    fileInput.addEventListener('change', function(event) {
        const file = event.target.files[0];
        const url = URL.createObjectURL(file);
        videoPlayer.src = url;
        addVideoToPlaylist(file.name, url);
        addMostWatchedVideo(file.name, url); // إضافة الفيديو إلى قائمة الفيديوهات الأكثر مشاهدة
    });

    playbackRateSelect.addEventListener('change', function(event) {
        videoPlayer.playbackRate = parseFloat(event.target.value);
    });

    qualitySelect.addEventListener('change', function(event) {
        const selectedQuality = event.target.value;
        const currentTime = videoPlayer.currentTime;
        videoPlayer.src = '';
        videoPlayer.src = videoPlayer.src = "video.mp4";
        videoPlayer.currentTime = currentTime;
        videoPlayer.play();
    });

    function addVideoToPlaylist(fileName, url) {
        const li = document.createElement('li');
        const title = document.createElement('span');
        title.textContent = fileName;
        li.appendChild(title);
        const renameBtn = document.createElement('button');
        renameBtn.textContent = 'إعادة تسمية';
        renameBtn.addEventListener('click', function() {
            const newName = prompt('أدخل اسماً جديداً للفيديو:', fileName);
            if (newName !== null && newName !== '') {
                title.textContent = newName;
            }
        });
        li.appendChild(renameBtn);
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'حذف';
        deleteBtn.addEventListener('click', function() {
            playlist.removeChild(li);
        });
        li.appendChild(deleteBtn);
        li.addEventListener('click', function() {
            videoPlayer.src = url;
            videoPlayer.play();
        });
        playlist.appendChild(li);
    }

    function addMostWatchedVideo(fileName, url) {
        const li = document.createElement('li');
        const title = document.createElement('span');
        title.textContent = fileName;
        li.appendChild(title);
        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'حذف';
        deleteBtn.addEventListener('click', function() {
            mostWatched.removeChild(li);
        });
        li.appendChild(deleteBtn);
        li.addEventListener('click', function() {
            videoPlayer.src = url;
            videoPlayer.play();
        });
        mostWatched.appendChild(li);
    }
};
